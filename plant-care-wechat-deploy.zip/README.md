# 植物养护微信H5应用

基于微信公众号的植物养护助手，集成AI识别、智能咨询、社区分享等功能。

## 🌟 功能特性

- 🔍 **AI植物识别**: 拍照识别植物种类，获取专业养护建议
- 📝 **养护记录**: 记录浇水、施肥、修剪等养护活动
- 💡 **AI咨询**: 智能问答，解决植物养护问题
- 👥 **社区分享**: 与植友分享养护经验和美图
- 📊 **数据统计**: 养护数据可视化分析
- 🔔 **智能提醒**: 基于植物特性的个性化提醒

## 🏗️ 技术架构

### 前端
- **Vue.js 3** - 渐进式JavaScript框架
- **Vant UI** - 移动端组件库
- **Vue Router** - 路由管理
- **Vuex** - 状态管理
- **微信JS-SDK** - 微信功能集成

### 后端
- **Node.js + Express** - 服务端框架
- **JWT** - 用户认证
- **MySQL** - 数据存储
- **Prisma/TypeORM** - 数据库ORM

### 部署方案
- **Vercel** - 前后端部署（免费）
- **PlanetScale** - MySQL数据库（免费）
- **Cloudinary** - 图片存储（免费）
- **百度智能云** - AI服务（免费额度）

## 🚀 快速开始

### 环境要求
- Node.js >= 16.0.0
- npm >= 8.0.0

### 安装依赖
```bash
# 安装后端依赖
npm install

# 安装前端依赖
cd client && npm install
```

### 环境配置
1. 复制环境变量文件
```bash
cp .env.example .env
```

2. 配置环境变量
```env
# 微信配置
WECHAT_APP_ID=你的微信AppID
WECHAT_APP_SECRET=你的微信AppSecret

# 数据库配置
DATABASE_URL=mysql://username:password@host:port/database

# AI服务配置
BAIDU_API_KEY=你的百度API密钥
BAIDU_SECRET_KEY=你的百度Secret密钥

# 其他配置...
```

### 开发运行
```bash
# 同时启动前后端开发服务器
npm run dev

# 或分别启动
npm run server:dev  # 后端服务器
npm run client:dev  # 前端开发服务器
```

### 生产构建
```bash
# 构建前端
npm run build

# 启动生产服务器
npm start
```

## 📱 微信公众号配置

### 1. 服务器配置
在微信公众平台后台配置：
- **服务器地址**: `https://your-domain.vercel.app/api/wechat/verify`
- **Token**: `plant_care_token_2024`
- **消息加解密方式**: 明文模式

### 2. 网页授权域名
在公众号设置中添加：
- `your-domain.vercel.app`

### 3. JS接口安全域名
在公众号设置中添加：
- `your-domain.vercel.app`

### 4. 创建自定义菜单
```bash
# 调用API创建菜单
curl -X POST https://your-domain.vercel.app/api/wechat/menu/create
```

## 🗄️ 数据库设计

### 核心表结构
- `T_WECHAT_USER` - 微信用户信息
- `T_USER_PLANT` - 用户植物档案
- `T_CARE_RECORD` - 养护记录
- `T_AI_CONSULTATION` - AI咨询记录
- `T_COMMUNITY_POST` - 社区动态
- `T_PLANT_KNOWLEDGE` - 植物知识库

详细设计参见：`database_final_design.sql`

## 🔌 API接口

### 用户管理
- `POST /api/user/wechat-login` - 微信登录
- `GET /api/user/profile` - 获取用户信息
- `PUT /api/user/profile` - 更新用户信息

### 植物管理
- `POST /api/plant/add` - 添加植物
- `GET /api/plant/list` - 获取植物列表
- `GET /api/plant/:id` - 获取植物详情
- `PUT /api/plant/:id` - 更新植物信息

### AI服务
- `POST /api/ai/identify` - 植物识别
- `POST /api/ai/consult` - AI咨询
- `GET /api/ai/history` - 咨询历史

详细接口文档参见：`api_design.md`

## 🎨 页面结构

```
/                   # 首页
/login             # 登录页
/plants            # 我的植物
/plant/add         # 添加植物
/plant/:id         # 植物详情
/care              # 养护记录
/care/add          # 添加养护记录
/ai/identify       # AI识别
/ai/consult        # AI咨询
/community         # 植友圈
/community/post    # 发布动态
/profile           # 个人中心
```

## 🔧 开发指南

### 代码规范
- 使用 ESLint + Prettier 进行代码格式化
- 遵循 Vue.js 官方风格指南
- 组件命名使用 PascalCase
- 文件命名使用 kebab-case

### 提交规范
```
feat: 新功能
fix: 修复bug
docs: 文档更新
style: 代码格式调整
refactor: 代码重构
test: 测试相关
chore: 构建过程或辅助工具的变动
```

## 📦 部署指南

### Vercel部署
1. 连接GitHub仓库到Vercel
2. 配置环境变量
3. 自动部署

### 环境变量配置
在Vercel后台配置所有必要的环境变量，参考`.env.example`

## 🤝 贡献指南

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 📞 联系方式

如有问题或建议，请通过以下方式联系：
- 微信公众号：植物养护助手
- 邮箱：support@plant-care.com

## 🙏 致谢

感谢以下开源项目和服务：
- Vue.js 团队
- Vant UI 团队
- Vercel 平台
- PlanetScale 数据库
- 百度智能云 AI 服务